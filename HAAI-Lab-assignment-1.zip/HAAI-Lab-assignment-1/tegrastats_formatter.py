#!/usr/bin/env python3

import sys
from datetime import datetime

with open("tegrastats.csv", mode="w") as f:
    for line in sys.stdin:
        sys.stdout.write(line)

        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        ### 
        # TODO: extract the cpu and gpu frequencies and utilization (CPU,GR3D_FREQ), 
        #       as well as the total power consumption (POM_5V_IN), and
        #       fill the following csv_line to be written into a csv file.
        ###
        csv_line = f"{now},..."
        print(csv_line, file=f)