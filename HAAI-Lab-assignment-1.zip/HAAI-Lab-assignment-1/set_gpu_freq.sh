#!/usr/bin/env bash

echo "$0 $@"

avail_freqs_file="/sys/devices/gpu.0/devfreq/57000000.gpu/available_frequencies"

if [[ ! $(cat $avail_freqs_file | tr -s ' ' '\n' | grep -e "$1$") ]]; then
    echo "Input is not valid. Available frequencies for GPU are:"
    cat $avail_freqs_file
    exit 0;
fi

cur_freq=$(cat /sys/devices/gpu.0/devfreq/57000000.gpu/cur_freq)

# min_freq=$(cat /sys/devices/gpu.0/devfreq/57000000.gpu/min_freq)
# max_freq=$(cat /sys/devices/gpu.0/devfreq/57000000.gpu/max_freq)
# echo $cur_freq 
# echo $min_freq 
# echo $max_freq

if [[ $1 -gt $cur_freq ]]; then
    sudo sh -c "echo $1 > /sys/devices/gpu.0/devfreq/57000000.gpu/max_freq"
    sudo sh -c "echo $1 > /sys/devices/gpu.0/devfreq/57000000.gpu/min_freq"
else
    sudo sh -c "echo $1 > /sys/devices/gpu.0/devfreq/57000000.gpu/min_freq"
    sudo sh -c "echo $1 > /sys/devices/gpu.0/devfreq/57000000.gpu/max_freq"
fi

cat /sys/devices/gpu.0/devfreq/57000000.gpu/min_freq
cat /sys/devices/gpu.0/devfreq/57000000.gpu/max_freq